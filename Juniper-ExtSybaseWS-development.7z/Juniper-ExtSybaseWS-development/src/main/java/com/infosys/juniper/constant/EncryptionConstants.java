package com.infosys.juniper.constant;

public class EncryptionConstants {
	
	
	public static final String ENCRYPTIONSERVICEURL = "http://localhost:8087/submit";

}
